const blankBody = `# Welcome to Honest Editor!

Hi! I'm your first Markdown file in **Honest Editor**. This is your markdown sandbox where you can play with Markdown.`;

export default blankBody;
